<?php
/// conn
$con = mysql_connect('HOSTNAME','USERNAME','PASSWORD');

mysql_connect($hostname,$username, $password) ou desconexão ("html>script language='JavaScript'>alert(“Não foi possível se conectar ao banco de dados! Tente novamente mais tarde.'),history.go(-1)/script>/html>");    
mysql_select_db('DATABASENAME', $con)

///////// var 

$tipoConversao = "tipoConversao";
$resultadoC = "resultadoC";
$resultadoK = "resultadoK";
$resultadoF = "resultadoF";


